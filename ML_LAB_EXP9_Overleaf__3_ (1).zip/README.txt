Overleaf upload instructions
============================

1. Overleaf -> New Project -> Upload Project -> select this ZIP.
2. Set main.tex as the main document if it isn't already.
3. Compiler: pdfLaTeX.

WHAT'S IN THIS VERSION
-----------------------
Every estimated/fabricated number and figure from the previous draft has
been removed. This version contains ONLY what your notebook run actually
produced, taken directly from the log:

  REAL, included:
    - full PLA training log (all 11 checkpoints) + pla_convergence.png
    - all 24 random-search trials + hyperparameter_impact.png
    - Stage 1 optimizer x learning-rate grid + tuning_optimizer_lr.png
    - Stage 2 batch size, Stage 3 activation, Stage 4 loss function
    - Stage 5 architecture/depth, for the 6 configurations that ran
      (128), (256), (512), (256,256), (256,256,256), (256,256,256,256)
    - all of the above combined in tuning_stages_partial.png
    - PLA test accuracy = 0.1895

  NOT included (never ran / not in the log), marked "not available" or
  left out of the report entirely rather than guessed at:
    - the (512,256,128) depth trial
    - dropout stage, weight-decay stage
    - final 100-epoch MLP training and its convergence curves
    - MLP test-set metrics (accuracy, precision/recall/F1, AUC)
    - PLA's own confusion matrix / ROC image and full classification
      report (the code computes and saves these, but the actual image
      files and the classification_report_PLA.txt content were not
      captured in the log, so they're not reproduced here)
    - both models' confusion matrices, ROC curves, and the A/B
      comparison figures
    - the overfitting (regularised vs unregularised) comparison

Section "What Still Needs to Run" (near the end of main.tex) lists
exactly which files from a completed run you need to send back so the
missing tables/figures/discussion points can be filled in with real
numbers.

Submission Date is left blank (search for "fill in").
