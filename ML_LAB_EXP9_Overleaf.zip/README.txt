Overleaf upload instructions
============================

1. Overleaf -> New Project -> Upload Project -> select this ZIP.
2. Set main.tex as the main document (Menu -> Main document) if it is not
   already selected.
3. Compiler: pdfLaTeX. No special packages required beyond a standard
   TeX Live install.

IMAGES
------
main.tex references the PNG files produced by the notebook into
/content/exp9_outputs. Upload them into the SAME folder as main.tex
(drag and drop into the Overleaf file tree, root level).

Files referenced, in order of appearance:

  samples.png                  (EDA sample grid)
  hyperparameter_impact.png    (random search impact)
  tuning_optimizer_lr.png      (optimizer x lr heatmap)
  tuning_stages.png            (stage-wise bars)
  pla_convergence.png          (PLA error + updates)
  mlp_convergence.png          (tuned MLP curves)        *not yet generated
  optimizer_convergence.png    (loss/error per optimizer)
  confusion_matrix_PLA.png
  confusion_matrix_MLP.png                               *not yet generated
  roc_PLA.png
  roc_MLP.png                                            *not yet generated
  ab_roc.png                                             *not yet generated
  ab_metrics.png                                         *not yet generated
  ab_convergence.png                                     *not yet generated
  overfitting_comparison.png                             *not yet generated

The starred files do not exist yet because the notebook run stopped
partway through the architecture/depth tuning stage. Re-run the notebook
end to end to produce them. Until then those \includegraphics lines will
fail to compile -- either comment out those figure environments or
temporarily use the draft option:
  \documentclass[12pt,a4paper,draft]{article}

PLACEHOLDERS
------------
24 red [FILL: ...] markers mark numbers the incomplete run did not
produce. Search main.tex for \TODO to find them all. Sources once the
notebook finishes:
  ab_comparison.csv        -> Results table (accuracy, P/R/F1, AUC)
  best_hyperparameters.json-> Final MLP configuration
  tuning_stages.csv        -> Dropout and weight-decay stage tables
  observations.txt         -> Overfitting gap numbers for Discussion Q5
